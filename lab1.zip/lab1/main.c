#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main()
{
    float C;
    char a;
    scanf("%f",&C);
    while(getchar() != '\n') a = getchar();
    if (a=='C')
    {
        printf("%.2f%c%c\n",(C*9/5)+32,' ','F');
        printf("%.2f%c%c\n",C+273.15,' ','K');
    }
    if ((a!='K') && (a!='C') && (a!='F'))
    {
        printf("%.2f%c%c\n",C,' ','C');
        printf("%.2f%c%c\n",(C*9/5)+32,' ','F');
        printf("%.2f%c%c\n",C+273.15,' ','K');
    }
    if (a=='F')
    {
        printf("%.2f%c%c\n",(C-32)*5/9,' ','C');
        printf("%.2f%c%c\n",((C-32)*5/9)+273.15,' ','K');
    }
    if (a=='K')
    {
        printf("%.2f%c%c\n",C-273.15,' ','C');
        printf("%.2f%c%c\n",((C-273.15)*9/5)+32,' ','F');
    }
    return 0;
}
